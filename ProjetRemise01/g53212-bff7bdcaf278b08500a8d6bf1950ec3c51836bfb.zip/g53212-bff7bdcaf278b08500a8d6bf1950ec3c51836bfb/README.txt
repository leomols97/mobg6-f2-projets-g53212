Application MOBG56 :

Une application informative qui listerait des événements passés sous forme de liste et des événements futurs sous forme de liste également.

Menu Hamburger dans lequel il y aura :

A. Accueil
B. Événements
E. Bières
F. Artistes
G. Recherche (À mettre au dessus)

A. Qu’est-ce que notre projet
B. Liste des événements passés ainsi que la possibilité de cliquer sur chaque événement pour en afficher plus d’infos (avec possibilité de retrouver les playlists) (avec une séparation visuelle entre les passés et les futurs) (faire des modals (genres de popup, mais en plus grand, qui invite à l’action) pour les infos supplémentaires)
E. Liste des bières promues ainsi que les brasseries associées
F. Liste des artistes promus ainsi qu’un lien vers leur page Instagram ainsi que la possibilité de voir leur interview qui a lieu après leur live
G. Possibilité de rechercher un artiste / brasserie / bière


